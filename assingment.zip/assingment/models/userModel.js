const db = require('./db');

module.exports = {
	search: function(user, callback){
		var sql = "select * from user where Name = '"+user.name+"'";
		db.getResults(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(false);
			}
		});
	},
	getrequest : function(callback){
		var sql = "select * from request";
		db.getResults(sql, function(results){	
				callback(results);
		});
	},
	insertrequest: function(user, callback){
		var data = user.reqest;
		var today = new Date();
		var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
		var time = today.getHours()+":" + today.getMinutes() + ":" +today.getSeconds();
		var dateTime = date+' '+time;
		var sql = "insert into request (request, Date) values ('"+data+"', '"+dateTime+"')";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	validate: function(user, callback){
		var sql = "select * from user where username = '"+user.username+"' and password = '"+user.password+"'";
		db.getResults(sql, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback(false);
			}
		});
	},
	checkgmail: function(campaign, callback){
		var sql = "select * from user where email = '"+campaign.email+"' or username = '"+campaign.username+"'";
		db.getResults(sql, function(results){
			if(results.length>0){
				callback(false);
			}else{
				callback(true);
			}
			
		});
	},
	getAll: function(callback){
		var value = 'modarator';
		var sql = "select * from user where type = '"+value+"'";
		db.getResults(sql, function(results){
			callback(results);
		});
	},
	insertmodarator: function(user, callback){
		var value = 'modarator';
		var sql = "insert into user (name, email, username, password, type) values('"+user.name+"','"+user.email+"', '"+user.username+"', '"+user.password+"', '"+value+"')";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getprofile : function(user, callback){
		console.log(user.id);
		var sql = "select * from user where id = '"+user.id+"'";
		db.getResults(sql, function(results){
			callback(results);
		});
	},
	insertadmin:function(user, callback){
		var value = 'admin';
		var sql = "insert into  user(name, email, username, password, type) values('"+user.name+"','"+user.email+"', '"+user.username+"', '"+user.password+"', '"+value+"')";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	insert: function(user, callback){
		var value = 'modarator';
		var sql = "insert into  user(name, email, username, password, type) values('"+user.name+"','"+user.email+"', '"+user.username+"', '"+user.password+"', '"+value+"')";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	update: function(user, callback){
		console.log(user);
		var sql = "update user set name = '"+user.name+"', email = '"+user.email+"', username = '"+user.username+"', password = '"+user.password+"' where id = '"+user.id+"'";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	delete: function(user, callback){
		var sql = "delete from user where id = '"+user.id+"'";
		db.execute(sql, function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}

