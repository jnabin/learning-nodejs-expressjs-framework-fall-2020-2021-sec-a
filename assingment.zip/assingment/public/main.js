
$(document).ready(function(){
	$('.search').click(function(){
		var name = $("#name").val();

		console.log(name);
		$.ajax({
			url: '/member_home/show',
			method: 'post',
			datatype : 'json',
			data : {'name':name},
			success:function(response){
				if(response.user !== 'error'){

					// $('#info').html(response.user.id);
					 
					$('#info').html('!!!search results found');
					// $('#info').html(response.user.username);
					// $('#info').html(response.user.password);
					$('#name').val('');
					
				}else{
					$('#info').html('<hr>'+'**can not found!!');
				}
			},
			error:function(response){
				alert('server error')
			}
		});
	});
});
