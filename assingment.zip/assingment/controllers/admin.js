const express 	= require('express');
const router 	= express.Router();
const userModel = require.main.require('./models/userModel')
const {body, validationResult} = require('express-validator');
const fs = require("fs");
const multer = require('multer');
const path = require('path');

router.get('*', (req, res, next)=>{
	if(req.session.admin){
		next();
	}else{
		res.redirect('/login');
	}
});

router.get('/create', (req, res)=>{
	
	res.render('admin/create');
	
});
router.get('/request', (req, res)=>{
	userModel.getrequest(function(results){
		res.render('home/request', {user:results});
	});
	
});
router.post('/create', [body('name').isLength({min: 1}), 
	 body('email').isLength({min: 1}), body('username').isLength({min: 1}), body('password').isLength({min: 1})], (req, res)=>{
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		return res.status(400).json({errors: errors.array()});
	}
	var user = {
		name : req.body.name,
		email : req.body.email,
		username : req.body.username,
		password : req.body.password
	}
	userModel.insert(user, function(status){
		if(status){
			res.redirect('/home/modaratorlist');
		}else{
			res.redirect('/admin/create');
		}
	});
});

router.get('/edit/:id/:name/:email/:username/:password', (req, res)=>{
	var currentUser = {
		name : req.params.name,
		email : req.params.email,
		username: req.params.username,
		password: req.params.password
	};
	res.render('admin/edit', currentUser);
});

router.get('/profile', (req, res)=>{
	var data ={
		id : req.session.aid
	}
	userModel.getprofile(data, function(results){
		res.render('admin/profile', {user:results[0]});
	});
});


router.get('/editprofile/:id/:name/:email/:username/:password', (req, res)=>{
	var currentUser = {
		name : req.params.name,
		email : req.params.email,
		username: req.params.username,
		password: req.params.password
	};
	res.render('admin/edit', currentUser);
});

router.post('/editprofile/:id/:name/:email/:username/:password', [body('name').isLength({min: 1}), 
	body('email').isLength({min: 1}), body('username').isLength({min: 1}), body('password').isLength({min: 1})],
	(req, res)=>{
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		return res.status(400).json({errors: errors.array()});
	}
	var user = {
		id : req.params.id,
		name : req.body.name,
		email : req.body.email,
		username: req.body.username,
		password: req.body.password
	};
	userModel.update(user, function(status){
		if(status){
			res.redirect('/admin/profile');
		}else{
			res.redirect('/admin/editprofile');
		}
	});
});

router.post('/edit/:id/:name/:email/:username/:password', [body('name').isLength({min: 1}), 
	body('email').isLength({min: 1}), body('username').isLength({min: 1}), body('password').isLength({min: 1})],
	(req, res)=>{
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		return res.status(400).json({errors: errors.array()});
	}
	var user = {
		id : req.params.id,
		name : req.body.name,
		email : req.body.email,
		username: req.body.username,
		password: req.body.password
	};
	userModel.update(user, function(status){
		if(status){
			res.redirect('/home/modaratorlist');
		}else{
			res.redirect('/admin/edit');
		}
	});
});

router.get('/delete/:id/:name/:email/:username/:password', (req, res)=>{
	
	var currentUser = {
		id : req.params.id,
		name : req.params.name,
		email : req.params.email,
		username: req.params.username,
		password: req.params.password
	};
	res.render('admin/delete', currentUser);
});

router.post('/delete/:id/:name/:email/:username/:password', (req, res)=>{

	var user = {
		id : req.params.id
	};
	userModel.delete(user, function(status){
		if(status){
			res.redirect('/home/modaratorlist');
		}else{
			res.redirect('/admin/delete');
		}
	});
});

const storage2 = multer.diskStorage({
	destination: './public/upload/file',
	filename: function(req, file, cb){
		if((file.originalname).length>9){
			cb(null, (file.originalname).substring(0, 9)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else if((file.originalname).length>4){
			cb(null, (file.originalname).substring(0, 4)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else if((file.originalname).length>1){
			cb(null, (file.originalname).substring(0, 1)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else{
			cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
	
		}
		
	}
});

function checkFileType(file, cb){
	const filetypes = /mp4|mkv|avi|3gp/;
	const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
	const mimetype = filetypes.test(file.mimetype);
	console.log(mimetype);
	console.log("mimetype");

	if(mimetype && extname){
		console.log("mimetype");
		return cb(null, true);
	} else{
		cb('Error: video Only!');
	}

}


const upload2 = multer({
	storage: storage2
}).single('file');

router.get('/uploadvideo', (req, res)=>{
	res.render('admin/uploadvideo', {msg: req.query.msg});
	
});

router.get('/uploadfile', (req, res)=>{
	res.render('admin/uploadfile', {msg: req.query.msg});
	
});

router.post('/uploadfile', (req, res)=>{
	upload2(req, res, (err)=>{
		console.log("hhghdhhsdghsdf");
		if(err){
			console.log(err);
			res.render('admin/uploadfile', {
				msg: err
			});
		}else{
			if(req.file == undefined){
				res.render('admin/uploadfile', {
					msg: 'Error: No file Selected'
				});
			}else{
				    res.redirect('/reload');
			}
		}
	});
});


module.exports = router;