const express = require('express');
const userModel = require.main.require('./models/userModel');
router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('*', (req, res, next)=>{
	if(req.session.admin){
		next();
	}else{
		res.redirect('/login');
	}
});
router.get('/', (req, res)=>{

let directory_name = 'public/upload/file';
let filenames = fs.readdirSync(directory_name); 

	const currentPath = 'public/upload/file';
	filenames.forEach(function(std){
		console.log(std);
		if(/.jpeg|.jpg|.png|.gif/.test(path.extname(std).toLowerCase())){
			const newPath = 'public/upload/image';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});
						
		}else if(/.pdf|.txt|.docs/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/documents';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/video';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/video';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp3|.wav/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/music';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else{
			const newPath = 'public/upload/software';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});
		}
	});
	let directory_name0 = 'public/upload/image';
	let images = fs.readdirSync(directory_name0);
	let directory_name1 = 'public/upload/video';
	let videos = fs.readdirSync(directory_name1);
	let directory_name2 = 'public/upload/documents';
	let documents = fs.readdirSync(directory_name2);
	let directory_name3 = 'public/upload/music';
	let music = fs.readdirSync(directory_name3);
	let directory_name4 = 'public/upload/software';
	let software = fs.readdirSync(directory_name4); 
	res.render('home/index', {name: 'nabin', msg: "File uploaded!", id : '123', image:images, video:videos, documents:documents, music:music, software:software});
});

module.exports = router;
