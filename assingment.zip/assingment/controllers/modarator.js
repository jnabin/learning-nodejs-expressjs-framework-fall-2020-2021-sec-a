const express 	= require('express');
const router 	= express.Router();
const userModel = require.main.require('./models/userModel')
const {body, validationResult} = require('express-validator');
const fs = require("fs");
const multer = require('multer');
const path = require('path');

router.get('*', (req, res, next)=>{
	if(req.session.modarator){
		next();
	}else{
		res.redirect('/login');
	}
});

router.get('/request', (req, res)=>{
	userModel.getrequest(function(results){
		res.render('modarator_home/request', {user:results});
	});
	
});

router.get('/profile', (req, res)=>{
	var data ={
		id : req.session.mid
	}
	userModel.getprofile(data, function(results){
        console.log(results);
		res.render('modarator/profile', {user:results[0]});
	});
});

router.get('/editprofile/:id/:name/:email/:username/:password', (req, res)=>{
	var currentUser = {
		name : req.params.name,
		email : req.params.email,
		username: req.params.username,
		password: req.params.password
	};
	res.render('modarator/edit', currentUser);
});

router.post('/editprofile/:id/:name/:email/:username/:password', [body('name').isLength({min: 1}), 
	body('email').isLength({min: 1}), body('username').isLength({min: 1}), body('password').isLength({min: 1})],
	(req, res)=>{
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		return res.status(400).json({errors: errors.array()});
	}
	var user = {
		id : req.params.id,
		name : req.body.name,
		email : req.body.email,
		username: req.body.username,
		password: req.body.password
	};
	userModel.update(user, function(status){
		if(status){
			res.redirect('/modarator/profile');
		}else{
			res.redirect('/modarator/editprofile');
		}
	});
});


const storage2 = multer.diskStorage({
	destination: './public/upload/file',
	filename: function(req, file, cb){
		if((file.originalname).length>9){
			cb(null, (file.originalname).substring(0, 9)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else if((file.originalname).length>4){
			cb(null, (file.originalname).substring(0, 4)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else if((file.originalname).length>1){
			cb(null, (file.originalname).substring(0, 1)+ file.fieldname + '-' + Date.now() + path.extname(file.originalname));
		}else{
			cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
	
		}
		
	}
});

function checkFileType(file, cb){
	const filetypes = /mp4|mkv|avi|3gp/;
	const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
	const mimetype = filetypes.test(file.mimetype);
	console.log(mimetype);
	console.log("mimetype");

	if(mimetype && extname){
		console.log("mimetype");
		return cb(null, true);
	} else{
		cb('Error: video Only!');
	}

}

const upload2 = multer({
	storage: storage2
}).single('file');
router.get('/uploadfile', (req, res)=>{
	res.render('modarator/uploadfile', {msg: req.query.msg});
	
});

router.post('/uploadfile', (req, res)=>{
	upload2(req, res, (err)=>{
		if(err){
			console.log(err);
			res.render('modarator/uploadfile', {
				msg: err
			});
		}else{
			if(req.file == undefined){
				res.render('modarator/uploadfile', {
					msg: 'Error: No file Selected'
				});
			}else{
                var mg = encodeURIComponent("uploaded!!");
				    res.redirect('/modarator_home?msg='+mg);
			}
		}
	});
});


module.exports = router;