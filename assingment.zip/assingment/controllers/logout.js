const express = require('express');
const router = express.Router();

router.get('/', (req, res)=>{
	req.session.admin = "";
	req.session.modarator = "";
	req.session.aid = "";
	req.session.mid = "";
	res.redirect('/login');
});

module.exports = router;