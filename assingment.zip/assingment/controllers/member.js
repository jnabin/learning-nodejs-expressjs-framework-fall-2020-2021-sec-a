const express 	= require('express');
const router 	= express.Router();
const userModel = require.main.require('./models/userModel')
const {body, validationResult} = require('express-validator');
const fs = require("fs");
const multer = require('multer');
const path = require('path');

router.get('/image', (req, res)=>{
    let directory_name = 'public/upload/file';
    let filenames = fs.readdirSync(directory_name); 
    
        const currentPath = 'public/upload/file';
        filenames.forEach(function(std){
            console.log(std);
            if(/.jpeg|.jpg|.png|.gif/.test(path.extname(std).toLowerCase())){
                const newPath = 'public/upload/image';
                fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
                  if (err) throw err;
                  console.log('source.txt was copied to destination.txt');
                });
                            
            }
        });
        let directory_name0 = 'public/upload/image';
        let images = fs.readdirSync(directory_name0);
        res.render('member/image', {name: 'nabin', id : '123', image:images});
});
router.get('/video', (req, res)=>{
    let directory_name = 'public/upload/file';
    let filenames = fs.readdirSync(directory_name); 
    
        const currentPath = 'public/upload/file';
        filenames.forEach(function(std){
            console.log(std);
            if(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase())){
                const newPath = 'public/upload/video';
                fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
                  if (err) throw err;
                  console.log('source.txt was copied to destination.txt');
                });
                            
            }
        });
        let directory_name1 = 'public/upload/video';
        let videos = fs.readdirSync(directory_name1);
        res.render('member/video', {name: 'nabin', id : '123', video:videos});
});
router.get('/documents', (req, res)=>{
    let directory_name = 'public/upload/file';
    let filenames = fs.readdirSync(directory_name); 
    
        const currentPath = 'public/upload/file';
        filenames.forEach(function(std){
            console.log(std);
            if(/.pdf|.txt|.docs/.test(path.extname(std).toLowerCase())){
                const newPath = 'public/upload/documents';
                fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
                  if (err) throw err;
                  console.log('source.txt was copied to destination.txt');
                });
                            
            }
        });
        let directory_name2 = 'public/upload/documents';
	let documents = fs.readdirSync(directory_name2);
        res.render('member/documents', {name: 'nabin', id : '123', documents:documents});
});
router.get('/softwareandgame', (req, res)=>{
    let directory_name = 'public/upload/file';
    let filenames = fs.readdirSync(directory_name); 
    
        const currentPath = 'public/upload/file';
        filenames.forEach(function(std){
            console.log(std);
            if(!(/.jpeg|.jpg|.png|.gif/.test(path.extname(std).toLowerCase())) && !(/.mp3|.wav/.test(path.extname(std).toLowerCase())) && !(/.pdf|.txt|.docs/.test(path.extname(std).toLowerCase())) && !(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase()))){
                const newPath = 'public/upload/software';
                fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
                  if (err) throw err;
                  console.log('source.txt was copied to destination.txt');
                });
                            
            }
        });
        let directory_name4 = 'public/upload/software';
	let software = fs.readdirSync(directory_name4); 
        res.render('member/softwareandgame', {name: 'nabin', id : '123', software:software});
});
router.get('/music', (req, res)=>{
    let directory_name = 'public/upload/file';
    let filenames = fs.readdirSync(directory_name); 
    
        const currentPath = 'public/upload/file';
        filenames.forEach(function(std){
            console.log(std);
            if(/.mp3|.wav/.test(path.extname(std).toLowerCase())){
                const newPath = 'public/upload/music';
                fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
                  if (err) throw err;
                  console.log('source.txt was copied to destination.txt');
                });
                            
            }
        });
        let directory_name3 = 'public/upload/music';
        let music = fs.readdirSync(directory_name3);
        res.render('member/music', {name: 'nabin', id : '123', music:music});
});

module.exports = router;