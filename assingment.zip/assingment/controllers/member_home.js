const express = require('express');
const userModel = require.main.require('./models/userModel')
const {body, validationResult} = require('express-validator');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { title } = require('process');

router.get('/', (req, res)=>{
    if(req.session.admin){
		req.session.admin = "";
	}
	if(req.session.modarator){
		req.session.modarator = "";
	}
    var s = req.session.errors;
	req.session.errors = "";
    let directory_name = 'public/upload/file';
let filenames = fs.readdirSync(directory_name); 
	const currentPath = 'public/upload/file';
	filenames.forEach(function(std){
		console.log(std);
		if(/.jpeg|.jpg|.png|.gif/.test(path.extname(std).toLowerCase())){
			const newPath = 'public/upload/image';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});
						
		}else if(/.pdf|.txt|.docs/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/documents';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/video';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp4|.mkv|.avi|.3gp/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/video';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else if(/.mp3|.wav/.test(path.extname(std).toLowerCase())){

			const newPath = 'public/upload/music';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});

		}else{
			const newPath = 'public/upload/software';
			fs.copyFile(currentPath+'/'+std, newPath+'/'+std, (err) => {
			  if (err) throw err;
			  console.log('source.txt was copied to destination.txt');
			});
		}
	});
	let directory_name0 = 'public/upload/image';
	let images = fs.readdirSync(directory_name0);
	let directory_name1 = 'public/upload/video';
	let videos = fs.readdirSync(directory_name1);
	let directory_name2 = 'public/upload/documents';
	let documents = fs.readdirSync(directory_name2);
	let directory_name3 = 'public/upload/music';
	let music = fs.readdirSync(directory_name3);
	let directory_name4 = 'public/upload/software';
	let software = fs.readdirSync(directory_name4); 
	res.render('member_home/index', {msg1 : s, name: 'nabin', msg: req.query.msg, id : '123', image:images, video:videos, documents:documents, music:music, software:software});
});
router.post('/', [body('request', '*request should be at leat 5 caracters long').isLength({min:5})], (req, res)=>{
    const errors = validationResult(req);
	if(!errors.isEmpty()){
		req.session.errors = errors.array()
		res.redirect('/member_home');
	}else{
        var e = req.body.request;
        data= {
            reqest : e
        }
        userModel.insertrequest(data, function(status){
            if(status){
                var msg =encodeURIComponent("!!request send succesfully");
                res.redirect('/member_home?msg='+msg);
            }else{
                console.log("error inserting request");
            }
        });
    }

});
router.post('/show', (req, res)=>{
    var c =  req.body.name;
	var title = {
		name : req.body.name
	};
    if(title.name == 'video' || title.name == 'music' ||title.name == 'game' ||title.name == 'software' || title.name == 'documents' || title.name == 'photo' || title.name == 'image'){
        res.json({campaign:['success']});
    }else{
        res.json({campaign:'error'});
    }
	
});
module.exports = router;