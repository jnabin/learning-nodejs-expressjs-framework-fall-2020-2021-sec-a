const express = require('express');
const router = express.Router();
const userModel = require.main.require('./models/userModel');
const {body, validationResult} = require('express-validator');

router.get('/', (req, res)=>{
	if(req.session.admin){
		req.session.admin = "";
	}
	if(req.session.modarator){
		req.session.modarator = "";
	}
	res.render('login/index', {msg:req.query.msg});
});

router.post('/', [body('username').isLength({min: 1}), body('password').isLength({min: 1})], (req, res)=>{
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		return res.status(400).json({errors: errors.array()});
	}
	var user = {
		username : req.body.username,
		password : req.body.password
	}
	userModel.validate(user, function(results){
		if(results){
			if(results[0].type == 'admin'){
				req.session.admin = req.body.username;
				req.session.aid = results[0].id;
				res.redirect('/home');
			}else{
				req.session.modarator = req.body.username;
				req.session.mid = results[0].id;
				res.redirect('/modarator_home')
			}
			
		}else{
			res.redirect('/login');
		}
	});
	
	
} );

module.exports = router;